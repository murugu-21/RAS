from django.shortcuts import render
import hashlib as hb
import random
from rest_framework import viewsets
from .serializers import *
from .models import *
from rest_framework.decorators import api_view
from rest_framework.response import Response 
from django.http import HttpResponse
from django.core.mail import send_mail
import csv
from django.core.files.storage import FileSystemStorage
from reportlab.platypus import Table
from reportlab.platypus import TableStyle
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Image
from reportlab.lib.pagesizes import letter
from django.db import connection
import os
from datetime import datetime
from django.conf import settings
from django.core.files import File
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
import pandas as pd
import matplotlib.pyplot as plt
import traceback
from django.http import FileResponse, Http404
from tempfile import NamedTemporaryFile
from InvoiceGenerator.api import Invoice, Item, Client, Provider, Creator
from InvoiceGenerator.pdf import SimpleInvoice

def my_custom_sql(st, date_given):
    with connection.cursor() as cursor:
        cursor.execute(st, [date_given])
        row = list(cursor.fetchall())

    return row


class LoginView(viewsets.ModelViewSet):
    serializer_class = LoginSerializer
    

@api_view(['POST'])
def loginCheck(request):
    if(request.method == 'POST'):
        current_email = request.data.get('email')
        
        current_password = request.data.get('password')
        
        try:
            login_row = Login.objects.get(pk=current_email)
        except:
            return Response({"err":"email", "msg":"Email does not exist"})
        if(login_row.password == hb.sha256(current_password.encode()).hexdigest()):
            request.session['email'] = current_email
            return Response({"email":current_email, "type":login_row.type})
            
        else:

            return Response({"err":"password", "msg":'Wrong password'})

@api_view(['POST'])
def get_users(request):
    if(request.method == 'POST'):
        
        try:
            users = list(Login.objects.all().values())
        except:
            return Response([])
        
        return Response(users)
            
@api_view(['POST'])
def create_user(request):
    if(request.method == 'POST'):
        
        try:
            data = request.data
            
            if Login.objects.filter(pk=data["email"]).exists():
                return Response('User already exists')
            new_user = Login(email= data["email"], password= hb.sha256(data["password"].encode()).hexdigest(), type= data["type"])
            new_user.save()
        except:
            return Response('db error')
        
        return Response('Success')


@api_view(['POST'])
def deleteUsers(request):
    if(request.method == 'POST'):
        current_email = request.data.get('email')
        try:
            login_row = Login.objects.get(pk=current_email)
        except:
             return Response("NO user found")
    login_row.delete()
    users = list(Login.objects.all().values())
    return Response(users)


@api_view(['POST'])
def ForgotPassword(request):
    if(request.method == 'POST'):
        data = request.data
        try:
            if Login.objects.filter(pk=data["email"]).exists():
                otp = ''.join([str(random.randint(0,9)) for i in range(7)])
                send_mail(
                    'Otp for ras',
                    otp,
                    'hari.19cs@kct.ac.in',
                    [request.data['email']],                    
                    fail_silently=False,
                )
                
                user = Login.objects.get(pk = data["email"])
                user.Otp = otp
                user.save()

                return (Response({"cango": True}))
            else:
                return Response(" does not exist")
        except:
            return Response("Try After Some Time")

@api_view(['POST'])
def OtpValidation(request):
    if(request.method == 'POST'):
        data = request.data
        if data["number"] == Login.objects.get(pk=data["email"]).Otp:
            user = Login.objects.get(pk=data["email"])
            user.otp = ''
            user.save()
            return (Response({"cango": True}))
            
        else:
            user = Login.objects.get(pk=data["email"])
            user.otp = ''
            user.save()
            return Response("Otp Invalid")

@api_view(['POST'])
def ChangePassword(request):
    if(request.method == 'POST'):
        data = request.data
        if (data["password"]):
            user = Login.objects.get(pk=data["email"])
            #print(len(hb.sha256(data["password"].encode()).hexdigest()))
            user.password = hb.sha256(data["password"].encode()).hexdigest()
            user.save()
            return (Response({"cango": True}))
            
        else:
            return Response("Otp Invalid")

@api_view(['POST'])
def CreateCsv(request):
    filename = request.data['file']+".csv"

    if request.data['file'] == 'sales_report':
        data = pd.DataFrame(my_custom_sql("SELECT sales.item_code, food.name, sales.quantity, food.price*sales.quantity as COST , CAST(sales.date AS char) FROM food inner JOIN sales ON FOOD.ITEM_CODE = SALES.ITEM_CODE where date(sales.date) >= %s ", request.data['date']), columns = ["Item Code" , "Food name", "Quatity" , "Cost","Sale time"])

    elif request.data['file'] == 'purchase_report':
        data = pd.DataFrame(my_custom_sql("select purchase.ingredient_id, inventory.name, purchase.quantity, purchase.price, cast(purchase.date as char) from purchase inner join inventory on purchase.ingredient_id = inventory.ingredient_id where purchase.date >= %s ", request.data['date']), columns = ["Ingredient Id", "Ingredient name", "Quantity", "Price", "Purchase time"])
    
    else:
        sales_data = pd.DataFrame(my_custom_sql("SELECT sales.item_code, food.name, sales.quantity, food.price*sales.quantity as COST , CAST(sales.date AS char) FROM food inner JOIN sales ON FOOD.ITEM_CODE = SALES.ITEM_CODE where date(sales.date) >= %s ", request.data['date']), columns = ["Item Code" , "Food name", "Quatity" , "Cost","Sale time"])
        purchase_data = pd.DataFrame(my_custom_sql("select purchase.ingredient_id, inventory.name, purchase.quantity, purchase.price, cast(purchase.date as char) from purchase inner join inventory on purchase.ingredient_id = inventory.ingredient_id where purchase.date >= %s ", request.data['date']), columns = ["Ingredient Id", "Ingredient name", "Quantity", "Price", "Purchase time"])
        data = []
        total_sales = sales_data['Cost'].sum()
        total_purchase = purchase_data['Price'].sum()
        gross_income = total_sales - total_purchase
        data.append(("Total sales amount",total_sales))
        data.append(("Total purchase amount",total_purchase))
        data.append(("Loss",abs(gross_income)) if gross_income<0 else ("Profit", gross_income))
        data = pd.DataFrame(data)

    data.to_csv(filename)

    BASE_DIR = getattr(settings, "BASE_DIR", None)
    filepath = os.path.join(BASE_DIR,filename)
    
    with open(filepath, 'rb') as ex:
        file_data = ex.read()
    response = HttpResponse(file_data, content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="' + filename +'"'
    return response

@api_view(['POST'])
def CreateExcel(request):
    BASE_DIR = getattr(settings, "BASE_DIR", None)
    filename = request.data['file']+".xlsx"
    filepath = os.path.join(BASE_DIR, filename)
    writer = pd.ExcelWriter(filepath, engine="xlsxwriter")

    if request.data['file'] == 'sales_report':
        sheet_name = 'Sales Report'
        data = pd.DataFrame(my_custom_sql("SELECT sales.item_code, food.name, sales.quantity, food.price*sales.quantity as COST , CAST(sales.date AS char) FROM food inner JOIN sales ON FOOD.ITEM_CODE = SALES.ITEM_CODE where date(sales.date) >= %s ", request.data['date']), columns = ["Item Code" , "Food name", "Quatity" , "Cost","Sale time"])

    elif request.data['file'] == 'purchase_report':
        sheet_name = 'Purchase Report'
        data = pd.DataFrame(my_custom_sql("select purchase.ingredient_id, inventory.name, purchase.quantity, purchase.price, cast(purchase.date as char) from purchase inner join inventory on purchase.ingredient_id = inventory.ingredient_id where purchase.date >= %s ", request.data['date']), columns = ["Ingredient Id", "Ingredient name", "Quantity", "Price", "Purchase time"])
    
    else:
        sheet_name = 'Gross Income'
        sales_data = pd.DataFrame(my_custom_sql("SELECT sales.item_code, food.name, sales.quantity, food.price*sales.quantity as COST , CAST(sales.date AS char) FROM food inner JOIN sales ON FOOD.ITEM_CODE = SALES.ITEM_CODE where date(sales.date) >= %s ", request.data['date']), columns = ["Item Code" , "Food name", "Quatity" , "Cost","Sale time"])
        purchase_data = pd.DataFrame(my_custom_sql("select purchase.ingredient_id, inventory.name, purchase.quantity, purchase.price, cast(purchase.date as char) from purchase inner join inventory on purchase.ingredient_id = inventory.ingredient_id where purchase.date >= %s ", request.data['date']), columns = ["Ingredient Id", "Ingredient name", "Quantity", "Price", "Purchase time"])
        
        monthly_sales = fn('''
        select
            sum(if(month = 'Jan', total, 0)) as 'Jan',
            sum(if(month = 'Feb', total, 0)) as 'Feb',
            sum(if(month = 'Mar', total, 0)) as 'Mar',
            sum(if(month = 'Apr', total, 0)) as 'Apr',
            sum(if(month = 'May', total, 0)) as 'May',
            sum(if(month = 'Jun', total, 0)) as 'Jun',
            sum(if(month = 'Jul', total, 0)) as 'Jul',
            sum(if(month = 'Aug', total, 0)) as 'Aug',
            sum(if(month = 'Sep', total, 0)) as 'Sep',
            sum(if(month = 'Oct', total, 0)) as 'Oct',
            sum(if(month = 'Nov', total, 0)) as 'Nov',
            sum(if(month = 'Dec', total, 0)) as 'Dec'
            from(
                select date_format(sales.date, "%b") as month, sum(food.price*sales.quantity) as total
                from food inner join sales on sales.item_code = food.item_code
                where date(sales.date) <= now() and date(sales.date) >= date_add(now(), interval -12 month)
                group by date_format(date(sales.date), "%m-%Y")) as sub
        ''')

        monthly_purchase = fn('''
        select
            sum(if(month = 'Jan', total, 0)) as 'Jan',
            sum(if(month = 'Feb', total, 0)) as 'Feb',
            sum(if(month = 'Mar', total, 0)) as 'Mar',
            sum(if(month = 'Apr', total, 0)) as 'Apr',
            sum(if(month = 'May', total, 0)) as 'May',
            sum(if(month = 'Jun', total, 0)) as 'Jun',
            sum(if(month = 'Jul', total, 0)) as 'Jul',
            sum(if(month = 'Aug', total, 0)) as 'Aug',
            sum(if(month = 'Sep', total, 0)) as 'Sep',
            sum(if(month = 'Oct', total, 0)) as 'Oct',
            sum(if(month = 'Nov', total, 0)) as 'Nov',
            sum(if(month = 'Dec', total, 0)) as 'Dec'
            from(
                select date_format(purchase.date, "%b") as month, sum(purchase.price) as total
                from purchase inner join inventory on purchase.ingredient_id = inventory.ingredient_id
                where date(purchase.date) <= now() and date(purchase.date) >= date_add(now(), interval -12 month)
                group by date_format(date(purchase.date), "%m-%Y")) as sub
        ''')

        monthly_income = []
        for i in range(12):
            monthly_income.append(float(monthly_sales[0][i])-float(monthly_purchase[0][i]))
        mon = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
        curmonth = datetime.now().month
        curyear = datetime.now().year
        months = ["{} {}".format(i, str(curyear-1)) for i in mon[curmonth:]]
        cur_yr = ["{} {}".format(i, str(curyear)) for i in mon[:curmonth]]
        months.extend(cur_yr)

        plt.xlabel("Month")
        plt.ylabel("Income")
        plt.title("Monthly income comparison")
        plt.xticks( rotation=90)
        plt.axhline(y=0, c='g', linewidth = 1, ls='--')
        plt.plot(months, monthly_income)
        plt.savefig("monthly_comparison.png", bbox_inches = "tight")
        image_link = os.path.join(BASE_DIR,"monthly_comparison.png")

        data = []
        total_sales = sales_data['Cost'].sum()
        total_purchase = purchase_data['Price'].sum()
        gross_income = total_sales - total_purchase
        data.append(("Total sales amount",total_sales))
        data.append(("Total purchase amount",total_purchase))
        data.append(("Loss",abs(gross_income)) if gross_income<0 else ("Profit", gross_income))
        data = pd.DataFrame(data)

    data.to_excel(writer, sheet_name=sheet_name)
    worksheet = writer.sheets[sheet_name]
    worksheet.insert_image('E2',image_link)

    writer.save()

    with open(filepath, 'rb') as ex:
        file_data = ex.read()
    response = HttpResponse(file_data,content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = 'attachment; filename=StatisticalReport.xlsx'
    return response

@api_view(['POST'])
def Create_Pdf(request):
    filename = request.data['file'] + ".pdf"
    pdf = SimpleDocTemplate(filename, pagesize=letter) 
    BASE_DIR = getattr(settings, "BASE_DIR", None)

    customColor = colors.Color(red=(74.0/255),green=(98.0/255),blue=(255.0/255))
    customColor1 = colors.Color(red=(150.0/255),green=(180.0/255),blue=(255.0/255))
    customColor2= colors.Color(red=(255.0/255),green=(255.0/255),blue=(255.0/255))

    def setBackground(table, rowNumb):
        for i in range(1, rowNumb):
            if i % 2 == 0:
                bc = customColor1
            else:
                bc = customColor2
            
            ts = TableStyle(
                [
                ('BACKGROUND', (0,i),(-1,i), bc),
                ('BOX',(0,0),(-1,-1),1,colors.black),
                ('GRID',(0,0),(-1,-1),1,colors.black),
                ('BACKGROUND', (0,0), (-1,0), customColor),
                ('TEXTCOLOR',(0,0),(-1,0),colors.whitesmoke),
                ('ALIGN',(0,0),(-1,-1),'CENTER'),
                ('FONTSIZE', (0,0), (-1,0), 14),
                ('BOTTOMPADDING', (0,0), (-1,0), 12)]
            )
            table.setStyle(ts)
    
    def setIncomeBackground(table, rowNumb):
        for i in range(1, rowNumb):
            if i % 2 == 0:
                bc = customColor1
            else:
                bc = customColor2

            ts = TableStyle(
                [
                ('BACKGROUND', (0,i),(-1,i), bc),
                ('BOX',(0,0),(-1,-1),1,colors.black),
                ('GRID',(0,0),(-1,-1),1,colors.black),
                ('ALIGN',(0,0),(-1,-1),'CENTER'),]
            )
            table.setStyle(ts)

    elems = []

    if request.data['file'] == 'sales_report':
        sales_data = my_custom_sql("SELECT sales.item_code, food.name, sales.quantity, food.price*sales.quantity as COST , CAST(sales.date AS char) FROM food inner JOIN sales ON FOOD.ITEM_CODE = SALES.ITEM_CODE where date(sales.date) >= %s ", request.data['date'])
        sales_head = ["Item Code" , "Food name", "Quatity" , "Cost","Sale time"]
        sales_data.insert(0, sales_head)
        sales_table = Table(sales_data)
        setBackground(sales_table, len(sales_data))
        elems.append(Paragraph("Sales report from "+datetime.strptime(request.data['date'],"%Y-%m-%d").strftime("%d-%m-%Y"),ParagraphStyle("List", parent = getSampleStyleSheet()['Heading1'], alignment = 1, spaceAfter = 30)))
        elems.append(sales_table)
    
    elif request.data['file'] == 'purchase_report':
        purchase_data = my_custom_sql("select purchase.ingredient_id, inventory.name, purchase.quantity, purchase.price, cast(purchase.date as char) from purchase inner join inventory on purchase.ingredient_id = inventory.ingredient_id where purchase.date >= %s ", request.data['date'])
        purchase_head = ["Ingredient Id", "Ingredient name", "Quantity", "Price", "Purchase time"]
        purchase_data.insert(0, purchase_head)
        purchase_table = Table(purchase_data)
        setBackground(purchase_table, len(purchase_data))
        elems.append(Paragraph("Purchase report from "+datetime.strptime(request.data['date'],"%Y-%m-%d").strftime("%d-%m-%Y"),ParagraphStyle("List", parent = getSampleStyleSheet()['Heading1'], alignment = 1, spaceAfter = 30)))
        elems.append(purchase_table)

    else:
        sales_data = my_custom_sql("SELECT sales.item_code, food.name, sales.quantity, food.price*sales.quantity as COST , CAST(sales.date AS char) FROM food inner JOIN sales ON FOOD.ITEM_CODE = SALES.ITEM_CODE where date(sales.date) >= %s ", request.data['date'])
        purchase_data = my_custom_sql("select purchase.ingredient_id, inventory.name, purchase.quantity, purchase.price, cast(purchase.date as char) from purchase inner join inventory on purchase.ingredient_id = inventory.ingredient_id where purchase.date >= %s ", request.data['date'])
        monthly_sales = fn('''
        select
            sum(if(month = 'Jan', total, 0)) as 'Jan',
            sum(if(month = 'Feb', total, 0)) as 'Feb',
            sum(if(month = 'Mar', total, 0)) as 'Mar',
            sum(if(month = 'Apr', total, 0)) as 'Apr',
            sum(if(month = 'May', total, 0)) as 'May',
            sum(if(month = 'Jun', total, 0)) as 'Jun',
            sum(if(month = 'Jul', total, 0)) as 'Jul',
            sum(if(month = 'Aug', total, 0)) as 'Aug',
            sum(if(month = 'Sep', total, 0)) as 'Sep',
            sum(if(month = 'Oct', total, 0)) as 'Oct',
            sum(if(month = 'Nov', total, 0)) as 'Nov',
            sum(if(month = 'Dec', total, 0)) as 'Dec'
            from(
                select date_format(sales.date, "%b") as month, sum(food.price*sales.quantity) as total
                from food inner join sales on sales.item_code = food.item_code
                where date(sales.date) <= now() and date(sales.date) >= date_add(now(), interval -12 month)
                group by date_format(date(sales.date), "%m-%Y")) as sub
        ''')

        monthly_purchase = fn('''
        select
            sum(if(month = 'Jan', total, 0)) as 'Jan',
            sum(if(month = 'Feb', total, 0)) as 'Feb',
            sum(if(month = 'Mar', total, 0)) as 'Mar',
            sum(if(month = 'Apr', total, 0)) as 'Apr',
            sum(if(month = 'May', total, 0)) as 'May',
            sum(if(month = 'Jun', total, 0)) as 'Jun',
            sum(if(month = 'Jul', total, 0)) as 'Jul',
            sum(if(month = 'Aug', total, 0)) as 'Aug',
            sum(if(month = 'Sep', total, 0)) as 'Sep',
            sum(if(month = 'Oct', total, 0)) as 'Oct',
            sum(if(month = 'Nov', total, 0)) as 'Nov',
            sum(if(month = 'Dec', total, 0)) as 'Dec'
            from(
                select date_format(purchase.date, "%b") as month, sum(purchase.price) as total
                from purchase inner join inventory on purchase.ingredient_id = inventory.ingredient_id
                where date(purchase.date) <= now() and date(purchase.date) >= date_add(now(), interval -12 month)
                group by date_format(date(purchase.date), "%m-%Y")) as sub
        ''')
        print(monthly_purchase)
        monthly_income = []
        for i in range(12):
            monthly_income.append(float(monthly_sales[0][i])-float(monthly_purchase[0][i]))
        mon = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
        curmonth = datetime.now().month
        curyear = datetime.now().year
        months = ["{} {}".format(i, str(curyear-1)) for i in mon[curmonth:]]
        cur_yr = ["{} {}".format(i, str(curyear)) for i in mon[:curmonth]]
        months.extend(cur_yr)
        print(months)

        print(monthly_income)
        gross_income_data = []

        total_sales = sum([i[3] for i in sales_data])
        total_purchase = sum([i[3] for i in purchase_data])
        gross_income = total_sales - total_purchase
        gross_income_data.append(("Total sales amount",total_sales))
        gross_income_data.append(("Total purchase amount",total_purchase))
        gross_income_data.append(("Loss",abs(gross_income)) if gross_income<0 else ("Profit", gross_income))

        gross_income_table = Table(gross_income_data, colWidths=(4*inch,1*inch))


        plt.figure(figsize=(4,4))
        plt.xlabel("Month")
        plt.ylabel("Income")
        plt.title("Monthly income comparison")
        plt.xticks( rotation=90)
        plt.yticks(rotation=90)
        plt.axhline(y=0, c='g', linewidth = 1, ls='--')
        
        plt.plot(months, monthly_income, marker='o')
        plt.savefig("monthly_comparison.png", bbox_inches = "tight")
        image_link = os.path.join(BASE_DIR,"monthly_comparison.png")

        setIncomeBackground(gross_income_table, len(gross_income_data))
        elems.append(Paragraph("Gross Income from "+datetime.strptime(request.data['date'],"%Y-%m-%d").strftime("%d-%m-%Y"),ParagraphStyle("List", parent = getSampleStyleSheet()['Heading1'], alignment = 1,spaceAfter =30)))
        elems.append(gross_income_table)  
        elems.append(Paragraph("",ParagraphStyle("List", spaceAfter =15)))
        elems.append(Image(image_link))
        
    
    pdf.build(elems)
    #print("ok")
    #return Response("ok")
    try:
        path_to_file = os.path.join(BASE_DIR, filename)
        f = open(path_to_file, 'rb')
        pdfFile = File(f)
        response = HttpResponse(pdfFile, content_type = 'applicaiton/pdf')
        response['Content-Disposition'] = 'inline;filename="filename"'
        return response
    except FileNotFoundError:
        raise Http404()

@api_view(["GET"])   
def retreive_pdf(request):
    try:
        fs = FileSystemStorage()
        #BASE_DIR = getattr(settings, "BASE_DIR", None)
        filename = "sales_report.pdf"
        if fs.exists(filename):
            with fs.open(filename) as pdf:
                print("fine")
                response = HttpResponse(pdf, content_type='application/pdf')
                #response['Content-Disposition'] = 'attachment; filename="mypdf.pdf"' #user will be prompted with the browser’s open/save file
                response['Content-Disposition'] = 'inline; filename="mypdf.pdf"' #user will be prompted display the PDF in the browser
                print(response)
                return response

    except FileNotFoundError:
        raise Http404()
global bill_no 
bill_no = 1
@api_view(["POST"])   
def bill_generator(request):
    try:
        global bill_no
        fs = FileSystemStorage()
        os.environ["INVOICE_LANG"] = "en"
        print(request.data)
        table_no = request.data["no"]
        client = Client('Table ' + str(table_no)) 
        clerk = request.data["email"]
        provider = Provider('Restaurant', bank_account='2600420569', bank_code='2010')
        creator = Creator(clerk)
        invoice = Invoice(client, provider, creator)
        
        data = request.data["order"] # quantity,price, name
        invoice.currency_locale = 'en_IN'
        invoice.currency = "INR"
        invoice.number = bill_no
        bill_no += 1
        for item in data:
            invoice.add_item(Item(item[0], item[1], description=item[2], tax=14))
        filename = "invoice"+str(bill_no)+".pdf"
        pdf = SimpleInvoice(invoice)
        pdf.gen(filename, generate_qr_code=True)
        
        if fs.exists(filename):
            with fs.open(filename) as pdf:
                response = HttpResponse(pdf, content_type='application/pdf')
                #response['Content-Disposition'] = 'attachment; filename="mypdf.pdf"' #user will be prompted with the browser’s open/save file
                response['Content-Disposition'] = 'inline; filename={}'.format(filename) #user will be prompted display the PDF in the browser
                return response

    except FileNotFoundError:
        raise Http404()    
 
def fn(code):
    with connection.cursor() as cursor:
        cursor.execute(code)
        row = list(cursor.fetchall())
    return row

@api_view(['POST'])
def get_chart(request):

    if(request.method=='POST'):
        x=fn("select Food.name, sum(quantity) from sales join Food on (Food.item_code = sales.item_code) Where (Food.isvisible = 1) group by Food.item_code")
        color = []
        labels, data = zip(*x)
        l = len(data)
        while l>0:
            col ='rgba(' + str(random.randint(0, 200)) + "," + str(random.randint(0,200)) + "," + str(random.randint(0, 200)) + ", 0.5)"
            if col not in color:
                color.append(col)
                l-=1
            else:
                continue
    
        return Response({"labels":labels,"datasets":[{"label":"salesreport","data":data, "backgroundColor": color
            ,}]})             


@api_view(['POST'])
def update_price(request):
    try:
        changed = request.data
        for item in changed:
            query = "update food set price={} where item_code={}".format(changed[item], item)
            fn(query)
        return Response("Success")
    except:
        traceback.print_exc()
        return Response("Db error") 

@api_view(['POST'])
def GetFoodsForClerk(request):
    try:
        query = 'select UPPER(name), price, image, item_code from food where (isvisible = 1 && (name like "%{}%" || food.item_code like "%{}%"))'.format(request.data["val"],request.data["val"])
        result = fn(query)   
        return Response(result)
    except:
        traceback.print_exc()
        return Response("Db error") 

def fn2(code):
    with connection.cursor() as cursor:
        cursor.execute(code)
        row = dict(cursor.fetchall())
    return row

@api_view(['POST'])
def get_foods(request):
    query = "select item_code, name, price from food where food.isvisible = 1"
    result = fn(query)
    return Response(result)

@api_view(['POST'])
def getingredient_list(request):
    try:
        if(request.method=='POST'):
            query="select name from inventory"
            result = fn(query)
            result = [i[0] for i in result]
            #print(result)
            return Response(result)
        else:
            return Response("no inventory")
    except:
        traceback.print_exc()
 
@api_view(['POST'])
def add_food(request):
    try:
        if(request.method=='POST'):
            data=request.data
            ingredientsList = data["nameList"]
            quantityList = data["quantityList"]
            ingredientsdict=fn2("select name,ingredient_id from inventory")
            
            if Food.objects.filter(name=data["foodname"]).exists():
                return Response("food already exists")
            else:
                for i in range(0,len(ingredientsList)):
                    ingredientsList[i] = str(ingredientsdict[ingredientsList[i]])
                visibility=1
                if(int(data["price"])==0):
                    visibility=0
                ingListString = ",".join(ingredientsList)
                ingquantityString=",".join(quantityList)
                new_food = Food(name= data["foodname"].upper(),ingredient_list_id=ingListString,quantity_list=ingquantityString,price=data["price"],isvisible=visibility)
                new_food.save()
 
                return Response("food created")
    except:
        traceback.print_exc()
 
@api_view(['POST'])
def add_ingredients(request):
    try: 
        if(request.method=='POST'):
            data=request.data["name"]
            print(data)
            if Inventory.objects.filter(name=data).exists():
                return Response([(data + " already exists"),"warning"])
            new_ing=Inventory(name=data,quantity=0)
            new_ing.save()
            return Response(["ingredients created","success"])
    except:
        traceback.print_exc()


