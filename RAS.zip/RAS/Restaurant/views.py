from django.shortcuts import render

# Create your views here.
from rest_framework import viewsets
from .serializers import *
from .models import *
from django.http.response import JsonResponse
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response 
from django.contrib import messages
class LoginView(viewsets.ModelViewSet):
    serializer_class = LoginSerializer
    queryset = Login.objects.all()


@api_view(['POST'])
def loginCheck(request):
    if(request.method == 'POST'):
        current_email = request.data.get('email')
        
        current_password = request.data.get('password')
        
        try:
            login_row = Login.objects.get(pk=current_email)
        except:
            return Response("Email not valid")
        if(login_row.password == current_password):
            request.session['email'] = current_email
            return Response({"email":current_email, "type":login_row.type})
            
        else:
            return Response('Email or password is wrong')

   