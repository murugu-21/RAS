from django.conf.urls import url 
from Restaurant import views 
 
urlpatterns = [ 
    url(r'^api/loginCheck$', views.loginCheck),
]